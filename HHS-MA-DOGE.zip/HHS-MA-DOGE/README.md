# Massachusetts Medicaid & Healthcare Political Influence Investigation

## HHS T-MSIS / DOGE Dataset Analysis + OCPF Campaign Finance + Lobbying Registration

**Investigation Period:** 2018-2026  
**Data Sources:** CMS T-MSIS (227M rows), OCPF Campaign Finance, MA Secretary of State Lobbying Registration, IRS 990s, CTHRU State Vendor Payments, DOL OLMS Union Finances

---

## Overview

This repository documents a comprehensive investigation into Massachusetts Medicaid spending patterns, healthcare industry political influence, and the money trail connecting taxpayer-funded providers to the politicians who control their funding. The analysis combines the DOGE/HHS T-MSIS Medicaid claims dataset with state campaign finance records, lobbying disclosures, and nonprofit tax filings.

### Key Findings

- **State agencies billing themselves at 20× national average** — DDS residential habilitation at $10,000/claim vs $329-$665 in other states
- **$9B+ in DDS billing** through T-MSIS, with 83% flowing to nonprofits whose CEOs earn $380K-$797K while frontline workers make $12-21/hr
- **Registered lobbyists personally donating** to politicians they lobby — documented at BILH (45 flagged donations), Point32Health (30 flagged), MHA
- **$14M union PAC** funded by automatic $8.43 payroll deductions from PCA workers earning poverty wages
- **70.9% leadership targeting** by Point32Health — most concentrated donation pattern observed
- **$1.96M in unitemized "Operating Expenses"** across Point32Health ($1.54M) and Fallon Health ($423K)

---

## Entity Analysis Status

### ✅ Completed — Full OCPF + Lobbying Analysis

| Entity | Type | OCPF Total | Lobbying (4yr) | Key Finding |
|---|---|---|---|---|
| Riverside Community Care | Provider | $34,650 (242) | $16K | Revolving door CEO DiGravio |
| Beth Israel Lahey Health | Hospital | $52,553 (259) | $1.92M | Lobbyists donating to lobbying targets |
| Point32Health | Insurer | $63,341 (303) | $2.43M | 70.9% leadership targeting; $1.54M unitemized |
| Fallon Health | Insurer | ~$45K exec | $857K | $423K unitemized OpEx |
| Stavros Center | Provider | $692,634 (81,425) | $0 | 99% union payroll deductions |
| 1199 SEIU + PAC | Union | $24K + $14.09M PAC | $906K | $8.33M unexplained transfers |
| Northeast Arc | Provider | $6,847 (119) | $103K | $733M billing, minimal political footprint |
| MHA / MHAPAC | Trade Assoc | $41,525 + $380K PAC | TBD | Industry pass-through PAC mechanism |
| Mass General Brigham | Hospital | $91,396 (423) | $3.25M | Philbin $60K; CEO as lobbyist |
| Cambridge Health Alliance | Hospital | $44,755 (303) | $1.62M | Safety-net; CEO $1.5M + lobbies |
| Eliot Community Human Svcs | Provider | $127,116 (25,092) | TBD | 95% union PAC deductions |

### ✅ Completed — CTHRU Vendor Payments + 990 Executive Comp

| Organization | FY2025 DDS Payment | CEO Comp | 4yr Growth |
|---|---|---|---|
| Seven Hills Foundation | $129M | $797K | +47% |
| Vinfen Corporation | $100M | $590K | +59% |
| Advocates Inc | $98M | $420K | +128% |
| ServiceNet | $95M | — | +116% |
| May Institute | $66M | — | — |
| Northeast Arc | $38M | — | — |
| DDS Total | $3.42B | — | +51.4% |

### ❌ Remaining — OCPF + Lobbying Not Yet Pulled

**Tier 1 Providers:** Seven Hills, Vinfen, Tempus, Advocates, Bay Cove, May Institute, JRI, ServiceNet, Clinical & Support Options

**Tier 2 Elder ASAPs:** Mystic Valley, Springwell, Somerville-Cambridge, South Shore, Old Colony, Greater Lynn, Elder Svcs Merrimack Valley, Elder Svcs Berkshire, WestMass ElderCare, Highland Valley, Bristol, Coastline, LifePath

**Tier 3 Trade Associations:** ADDP, Providers' Council, ABH

**Other:** SEIU 509, Boston Medical Center, UMass Memorial

---

## Repository Structure

```
HHS-MA-DOGE/
├── README.md                          # This file
├── transcripts/                       # Full conversation transcripts (JSON)
│   ├── journal.txt                    # Transcript catalog
│   ├── 2026-02-15-19-57-41-ma-medicaid-doge-investigation.txt
│   ├── 2026-02-15-19-59-48-riverside-community-care-lobbying-analysis.txt
│   ├── 2026-02-15-20-17-01-bilh-lobbying-ocpf-analysis.txt
│   ├── 2026-02-15-20-25-56-point32health-lobbying-ocpf-analysis.txt
│   ├── 2026-02-15-20-28-46-fallon-stavros-lobbying-ocpf-analysis.txt
│   ├── 2026-02-15-20-39-51-1199seiu-union-lobbying-pac-analysis.txt
│   └── 2026-02-15-20-43-29-northeast-arc-mha-mhapac-analysis.txt
├── data/
│   ├── ocpf/
│   │   └── mha-employee-donations.txt       # 220 MHA employee donations
│   ├── mhapac/
│   │   └── mhapac-expenditures.txt          # 1,306 MHAPAC expenditures
│   └── lobbying/
│       ├── 1.pdf through 5.pdf              # Northeast Arc lobbying registrations
│       └── Lobbyist_Public_Search.pdf       # Lobbying search results
└── analysis/
    ├── master-comparison-table.csv          # All entities compared
    ├── lobbying-registration-summary.csv    # Year-by-year lobbying spend
    ├── cthru-dds-vendor-payments.csv        # DDS vendor payments FY2021-2025
    ├── nonprofit-executive-compensation.csv # CEO comp from 990s
    ├── red-flags-summary.csv               # All documented red flags
    └── confirmed-fraud-cases.csv           # Cross-referenced fraud cases
```

---

## Data Sources

| Source | URL | What |
|---|---|---|
| CMS T-MSIS | data.medicaid.gov | 227M Medicaid claims, provider spending |
| OCPF | ocpf.us/Data | MA campaign contributions |
| Lobbying Registry | sec.state.ma.us | Lobbyist registrations & expenditures |
| CTHRU | cthru.data.socrata.com | State vendor payments |
| ProPublica 990s | projects.propublica.org/nonprofits | Nonprofit tax filings |
| OIG LEIE | oig.hhs.gov/exclusions | Excluded providers list |
| NPPES NPI | npiregistry.cms.hhs.gov | Provider registry |
| DOL OLMS | olmsapps.dol.gov | Union financial reports |
| DataRepublican | datarepublican.com | NPI officer search, charity funding |

---

## Related Chats (Claude.ai)

- [Medicaid Provider Spending Analysis](https://claude.ai/chat/03812535-4f27-44ee-8721-92a2d5aedfcc) — T-MSIS analysis, CTHRU payments, 990s, fraud cases, investigation dashboard
- [Hospital Corruption / Nonprofit Lobbying](https://claude.ai/chat/3bc83599-d5e5-4edc-ada3-ea41a9590aa8) — MGB, CHA, BILH, Eliot OCPF; corruption scores; master summary

---

## Methodology

1. **T-MSIS Analysis**: 50 procedure codes filtered to Massachusetts, compared against national averages to identify outlier billing patterns
2. **OCPF Campaign Finance**: Employee donation data pulled for each entity, analyzed for coordination patterns, leadership targeting, lobbyist personal donations
3. **Lobbying Registration**: Secretary of State filings (2021-2025) compiled for in-house lobbyists, external firms, operating expenses
4. **CTHRU Vendor Payments**: DDS spending FY2021-FY2025 tracked by provider to establish funding trajectories
5. **990 Cross-Reference**: ProPublica Nonprofit Explorer for executive compensation, revenue, program service percentages
6. **Fraud Enforcement**: MA AG settlements, OIG exclusions, DOJ convictions cross-referenced against T-MSIS active billers

---

## License

Public domain. All data sourced from public records.
